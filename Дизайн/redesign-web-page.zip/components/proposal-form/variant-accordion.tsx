"use client"

import React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { 
  Collapsible, 
  CollapsibleContent, 
  CollapsibleTrigger 
} from "@/components/ui/collapsible"
import { Switch } from "@/components/ui/switch"
import { 
  ChevronDown,
  Building2, 
  Truck, 
  Package,
  Calculator,
  CreditCard,
  Plus,
  Trash2,
  Upload,
  FileDown,
  RefreshCw,
  Sparkles
} from "lucide-react"

interface Product {
  id: number
  name: string
  material: string
  quantity: number
  weight: number
  price: number
}

interface SectionProps {
  title: string
  icon: React.ReactNode
  badge?: string
  defaultOpen?: boolean
  children: React.ReactNode
}

function Section({ title, icon, badge, defaultOpen = false, children }: SectionProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen)
  
  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <CollapsibleTrigger className="w-full">
        <div className="flex items-center justify-between p-5 bg-card border rounded-xl hover:bg-muted/30 transition-colors">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
              {icon}
            </div>
            <span className="font-semibold text-lg">{title}</span>
            {badge && (
              <Badge variant="secondary" className="ml-2">{badge}</Badge>
            )}
          </div>
          <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </div>
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="p-6 mt-1 bg-card border rounded-xl">
          {children}
        </div>
      </CollapsibleContent>
    </Collapsible>
  )
}

export function VariantAccordion() {
  const [products, setProducts] = useState<Product[]>([
    { id: 1, name: "Деталь литая", material: "Сталь 45", quantity: 10, weight: 102, price: 24480 }
  ])

  const addProduct = () => {
    setProducts([...products, { 
      id: Date.now(), 
      name: "", 
      material: "", 
      quantity: 1, 
      weight: 0, 
      price: 0 
    }])
  }

  const removeProduct = (id: number) => {
    if (products.length > 1) {
      setProducts(products.filter(p => p.id !== id))
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Header */}
      <header className="relative bg-card border-b overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,transparent_0%,transparent_49%,var(--border)_50%,transparent_51%,transparent_100%)] bg-[length:100px_100%] opacity-30"></div>
        <div className="container mx-auto px-6 py-8 relative">
          <div className="flex items-start justify-between">
            <div>
              <Badge variant="outline" className="mb-3">Тендер ИП1434</Badge>
              <h1 className="text-3xl font-bold text-foreground mb-2 text-balance">
                Новое коммерческое предложение
              </h1>
              <p className="text-muted-foreground max-w-xl text-pretty">
                Заполните необходимые разделы для формирования коммерческого предложения. Все поля можно редактировать в любое время.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Сбросить
              </Button>
              <Button variant="outline">
                <FileDown className="w-4 h-4 mr-2" />
                Сохранить
              </Button>
              <Button>
                <Sparkles className="w-4 h-4 mr-2" />
                Сгенерировать КП
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-3 gap-8">
          {/* Left Column - Form Sections */}
          <div className="col-span-2 space-y-4">
            {/* Company Section */}
            <Section 
              title="Информация о клиенте" 
              icon={<Building2 className="w-5 h-5" />}
              defaultOpen={true}
            >
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <Label>Регион бюджета</Label>
                    <Select defaultValue="china">
                      <SelectTrigger className="h-11">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="china">Бюджет в юанях (Китай)</SelectItem>
                        <SelectItem value="russia">Бюджет в рублях (РФ)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Компания</Label>
                    <Input className="h-11" defaultValue='ОАО "Кузлитмаш"' />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Условия оплаты</Label>
                  <Input className="h-11" defaultValue="100% по факту поставки в течении 30 календарных дней" />
                </div>

                <div className="space-y-2">
                  <Label>Адрес доставки</Label>
                  <Textarea 
                    defaultValue="Республика Беларусь, Брестская обл., г. Пинск, 225710, пр. Жолтовского, 109"
                    rows={2}
                    className="resize-none"
                  />
                </div>

                <div className="grid grid-cols-3 gap-5">
                  <div className="space-y-2">
                    <Label>Срок действия</Label>
                    <div className="relative">
                      <Input className="h-11 pr-16" type="number" defaultValue="30" />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">дней</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Срок поставки</Label>
                    <div className="relative">
                      <Input className="h-11 pr-16" type="number" defaultValue="150" />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">дней</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Гарантийный срок</Label>
                    <Input className="h-11" defaultValue="12 месяцев" />
                  </div>
                </div>
              </div>
            </Section>

            {/* Logistics Section */}
            <Section 
              title="Расчёт логистики" 
              icon={<Truck className="w-5 h-5" />}
              badge="150 000 ₽"
            >
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <button className="p-4 border-2 border-primary rounded-xl bg-primary/5 text-left">
                    <p className="font-semibold">Фура</p>
                    <p className="text-sm text-muted-foreground">Стандартная доставка до 20т</p>
                  </button>
                  <button className="p-4 border-2 border-border rounded-xl hover:border-primary/50 text-left transition-colors">
                    <p className="font-semibold">Трал</p>
                    <p className="text-sm text-muted-foreground">Для негабаритных грузов</p>
                  </button>
                </div>

                <div className="grid grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label>Вес (кг)</Label>
                    <Input className="h-11" type="number" defaultValue="1020" />
                  </div>
                  <div className="space-y-2">
                    <Label>Габариты</Label>
                    <Input className="h-11" placeholder="ДхШхВ см" />
                  </div>
                  <div className="space-y-2">
                    <Label>Оценочный вес</Label>
                    <Input className="h-11 bg-muted" disabled defaultValue="1020 кг" />
                  </div>
                  <div className="space-y-2">
                    <Label>Город доставки</Label>
                    <Select defaultValue="brest">
                      <SelectTrigger className="h-11">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="brest">Брест</SelectItem>
                        <SelectItem value="minsk">Минск</SelectItem>
                        <SelectItem value="gomel">Гомель</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-muted/50 rounded-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-accent animate-pulse"></div>
                    <span className="text-sm text-muted-foreground">Рассчитанная стоимость:</span>
                    <span className="text-xl font-bold">150 000 ₽</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2">
                      <Switch id="use-suggestion" />
                      <Label htmlFor="use-suggestion" className="text-sm">Использовать подсказку</Label>
                    </div>
                    <Button variant="secondary" size="sm">
                      Пересчитать
                    </Button>
                  </div>
                </div>
              </div>
            </Section>

            {/* Products Section */}
            <Section 
              title="Товары и услуги" 
              icon={<Package className="w-5 h-5" />}
              badge={`${products.length} позиций`}
            >
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Switch id="common-margin" defaultChecked />
                    <Label htmlFor="common-margin">Общая маржа:</Label>
                    <Input type="number" defaultValue="25" className="w-20 h-9 text-center" />
                    <span className="text-muted-foreground">%</span>
                  </div>
                  <Button variant="outline" size="sm">
                    <Upload className="w-4 h-4 mr-2" />
                    Импорт из Excel
                  </Button>
                </div>

                <div className="space-y-3">
                  {products.map((product, index) => (
                    <div key={product.id} className="p-4 bg-muted/30 rounded-xl space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-muted-foreground">Позиция {index + 1}</span>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          onClick={() => removeProduct(product.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      
                      <div className="grid grid-cols-4 gap-3">
                        <div className="col-span-2 space-y-1">
                          <Label className="text-xs text-muted-foreground">Наименование</Label>
                          <Input defaultValue={product.name} />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Номер чертежа</Label>
                          <Input placeholder="ЧРТ-001" />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Материал</Label>
                          <Input defaultValue={product.material} />
                        </div>
                      </div>

                      <div className="grid grid-cols-5 gap-3">
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Кол-во (шт)</Label>
                          <Input type="number" defaultValue={product.quantity} />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Вес (кг/шт)</Label>
                          <Input type="number" defaultValue={product.weight} />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Цена закупа</Label>
                          <Input type="number" defaultValue={product.price} />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Пошлина (%)</Label>
                          <Input type="number" defaultValue="5" />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Цена/кг</Label>
                          <Input disabled className="bg-muted" defaultValue="240" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <Button variant="outline" className="w-full h-11 bg-transparent" onClick={addProduct}>
                  <Plus className="w-4 h-4 mr-2" />
                  Добавить позицию
                </Button>
              </div>
            </Section>

            {/* Financing Section */}
            <Section 
              title="Финансирование" 
              icon={<CreditCard className="w-5 h-5" />}
            >
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <label className="flex items-center gap-3 p-4 border-2 rounded-xl cursor-pointer hover:border-primary/50 transition-colors has-[:checked]:border-primary has-[:checked]:bg-primary/5">
                    <input type="checkbox" className="sr-only" />
                    <div className="w-5 h-5 rounded-md border-2 border-primary flex items-center justify-center">
                      <div className="w-3 h-3 rounded-sm bg-primary scale-0 has-[:checked]:scale-100 transition-transform"></div>
                    </div>
                    <div>
                      <p className="font-medium">Кредит</p>
                      <p className="text-sm text-muted-foreground">Финансирование сделки</p>
                    </div>
                  </label>
                  <label className="flex items-center gap-3 p-4 border-2 rounded-xl cursor-pointer hover:border-primary/50 transition-colors has-[:checked]:border-primary has-[:checked]:bg-primary/5">
                    <input type="checkbox" className="sr-only" />
                    <div className="w-5 h-5 rounded-md border-2 border-primary flex items-center justify-center">
                      <div className="w-3 h-3 rounded-sm bg-primary scale-0 has-[:checked]:scale-100 transition-transform"></div>
                    </div>
                    <div>
                      <p className="font-medium">Банковская гарантия</p>
                      <p className="text-sm text-muted-foreground">Обеспечение обязательств</p>
                    </div>
                  </label>
                </div>

                <div className="space-y-3">
                  <Label>Дополнительные расходы</Label>
                  <Button variant="outline" size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Добавить расход
                  </Button>
                </div>
              </div>
            </Section>
          </div>

          {/* Right Column - Summary */}
          <div className="col-span-1">
            <div className="sticky top-8 space-y-6">
              {/* Summary Card */}
              <div className="bg-card border rounded-2xl overflow-hidden">
                <div className="p-6 bg-primary text-primary-foreground">
                  <div className="flex items-center gap-2 mb-4">
                    <Calculator className="w-5 h-5" />
                    <h3 className="font-semibold">Итоговый расчёт</h3>
                  </div>
                  <div className="text-4xl font-bold mb-1">165 300 ¥</div>
                  <p className="text-primary-foreground/70 text-sm">Итоговая продажная цена</p>
                </div>

                <div className="p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Себестоимость ед.</span>
                    <span className="font-medium">7 500 ¥</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Логистика</span>
                    <span className="font-medium">150 000 ₽</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">НДС (15%)</span>
                    <span className="font-medium">25 050 ¥</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Таможенные платежи</span>
                    <span className="font-medium">1 224 ¥</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Маржа (3%)</span>
                    <span className="font-medium">541,75 ¥</span>
                  </div>

                  <div className="h-px bg-border my-4"></div>

                  <div className="p-4 bg-accent/10 rounded-xl">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-muted-foreground">Ожидаемая прибыль</span>
                      <span className="text-xl font-bold text-accent">11 339 ¥</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">Рентабельность</span>
                      <Badge className="bg-accent text-accent-foreground">5.54%</Badge>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-2 p-3 bg-muted rounded-lg text-sm">
                    <span className="text-muted-foreground">Курс:</span>
                    <span className="font-mono font-medium">1 ¥ = 14 ₽</span>
                  </div>
                </div>

                <div className="p-4 border-t space-y-2">
                  <Button className="w-full h-12 text-base" size="lg">
                    Предварительный расчёт
                  </Button>
                  <Button variant="outline" className="w-full bg-transparent">
                    Показать подробно
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
