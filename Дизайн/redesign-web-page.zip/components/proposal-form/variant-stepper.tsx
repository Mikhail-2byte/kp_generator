"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { 
  Building2, 
  MapPin, 
  Truck, 
  Package, 
  Calculator,
  ChevronRight,
  ChevronLeft,
  Check,
  Plus,
  Trash2
} from "lucide-react"

const steps = [
  { id: 1, title: "Компания", icon: Building2 },
  { id: 2, title: "Логистика", icon: Truck },
  { id: 3, title: "Товары", icon: Package },
  { id: 4, title: "Расчёт", icon: Calculator },
]

interface Product {
  id: number
  name: string
  material: string
  quantity: number
  weight: number
  price: number
}

export function VariantStepper() {
  const [currentStep, setCurrentStep] = useState(1)
  const [budgetRegion, setBudgetRegion] = useState("china")
  const [transportType, setTransportType] = useState("truck")
  const [products, setProducts] = useState<Product[]>([
    { id: 1, name: "Деталь А", material: "Сталь 45", quantity: 10, weight: 102, price: 15000 }
  ])

  const addProduct = () => {
    setProducts([...products, { 
      id: Date.now(), 
      name: "", 
      material: "", 
      quantity: 1, 
      weight: 0, 
      price: 0 
    }])
  }

  const removeProduct = (id: number) => {
    setProducts(products.filter(p => p.id !== id))
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Новое коммерческое предложение</h1>
              <p className="text-sm text-muted-foreground mt-1">Тендер: ИП1434</p>
            </div>
            <Badge variant="outline" className="text-sm font-mono">
              Черновик
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <div className="flex gap-8">
          {/* Stepper Navigation */}
          <aside className="w-64 flex-shrink-0">
            <nav className="sticky top-8 space-y-2">
              {steps.map((step, index) => {
                const Icon = step.icon
                const isActive = currentStep === step.id
                const isCompleted = currentStep > step.id
                
                return (
                  <button
                    key={step.id}
                    onClick={() => setCurrentStep(step.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all ${
                      isActive 
                        ? "bg-primary text-primary-foreground" 
                        : isCompleted 
                          ? "bg-muted text-foreground" 
                          : "text-muted-foreground hover:bg-muted/50"
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isActive 
                        ? "bg-primary-foreground/20" 
                        : isCompleted 
                          ? "bg-accent text-accent-foreground" 
                          : "bg-muted"
                    }`}>
                      {isCompleted ? <Check className="w-4 h-4" /> : <Icon className="w-4 h-4" />}
                    </div>
                    <span className="font-medium">{step.title}</span>
                  </button>
                )
              })}
            </nav>
          </aside>

          {/* Main Content */}
          <main className="flex-1 max-w-3xl">
            {/* Step 1: Company Info */}
            {currentStep === 1 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-primary" />
                    Информация о компании
                  </CardTitle>
                  <CardDescription>
                    Укажите данные клиента и условия сделки
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Регион бюджета</Label>
                    <RadioGroup 
                      value={budgetRegion} 
                      onValueChange={setBudgetRegion}
                      className="flex gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="china" id="china" />
                        <Label htmlFor="china" className="font-normal cursor-pointer">
                          Юани (Китай)
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="russia" id="russia" />
                        <Label htmlFor="russia" className="font-normal cursor-pointer">
                          Рубли (РФ)
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="tender">Номер тендера</Label>
                      <Input id="tender" defaultValue="ИП1434" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="validity">Срок действия (дней)</Label>
                      <Input id="validity" type="number" defaultValue="30" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company">Название компании</Label>
                    <Input id="company" defaultValue='ОАО "Кузлитмаш"' />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="payment">Условия оплаты</Label>
                    <Textarea 
                      id="payment" 
                      defaultValue="100% по факту поставки в течении 30 календарных дней"
                      rows={2}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Адрес доставки</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                      <Textarea 
                        id="address" 
                        className="pl-10"
                        defaultValue="Республика Беларусь, Брестская обл., г. Пинск, 225710, пр. Жолтовского, 109"
                        rows={2}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="delivery-days">Срок поставки (дней)</Label>
                      <Input id="delivery-days" type="number" defaultValue="150" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="warranty">Гарантийный срок</Label>
                      <Input id="warranty" defaultValue="12 месяцев" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 2: Logistics */}
            {currentStep === 2 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Truck className="w-5 h-5 text-primary" />
                    Расчёт логистики
                  </CardTitle>
                  <CardDescription>
                    Выберите тип транспорта и укажите параметры груза
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Тип транспорта</Label>
                    <RadioGroup 
                      value={transportType} 
                      onValueChange={setTransportType}
                      className="grid grid-cols-2 gap-4"
                    >
                      <Label 
                        htmlFor="truck" 
                        className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                          transportType === "truck" 
                            ? "border-primary bg-primary/5" 
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <RadioGroupItem value="truck" id="truck" className="sr-only" />
                        <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                          <Truck className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-medium">Фура</p>
                          <p className="text-sm text-muted-foreground">До 20 тонн</p>
                        </div>
                      </Label>
                      <Label 
                        htmlFor="trailer" 
                        className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-all ${
                          transportType === "trailer" 
                            ? "border-primary bg-primary/5" 
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <RadioGroupItem value="trailer" id="trailer" className="sr-only" />
                        <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                          <Package className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-medium">Трал</p>
                          <p className="text-sm text-muted-foreground">Негабарит</p>
                        </div>
                      </Label>
                    </RadioGroup>
                  </div>

                  <Separator />

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="weight">Вес груза (кг)</Label>
                      <Input id="weight" type="number" defaultValue="1020" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="dimensions">Габариты (ДхШхВ, см)</Label>
                      <Input id="dimensions" placeholder="200x100x150" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="city">Город доставки</Label>
                    <Select defaultValue="brest">
                      <SelectTrigger>
                        <SelectValue placeholder="Выберите город" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="brest">Брест</SelectItem>
                        <SelectItem value="minsk">Минск</SelectItem>
                        <SelectItem value="gomel">Гомель</SelectItem>
                        <SelectItem value="grodno">Гродно</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Расчётная стоимость</p>
                        <p className="text-2xl font-semibold">150 000 ₽</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Пересчитать
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 3: Products */}
            {currentStep === 3 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="w-5 h-5 text-primary" />
                    Товары и услуги
                  </CardTitle>
                  <CardDescription>
                    Добавьте позиции в коммерческое предложение
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {products.map((product, index) => (
                    <div key={product.id} className="p-4 border rounded-lg space-y-4">
                      <div className="flex items-center justify-between">
                        <Badge variant="secondary">Позиция {index + 1}</Badge>
                        {products.length > 1 && (
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => removeProduct(product.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Наименование</Label>
                          <Input defaultValue={product.name} placeholder="Название товара" />
                        </div>
                        <div className="space-y-2">
                          <Label>Материал</Label>
                          <Input defaultValue={product.material} placeholder="Материал" />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label>Кол-во (шт.)</Label>
                          <Input type="number" defaultValue={product.quantity} />
                        </div>
                        <div className="space-y-2">
                          <Label>Вес (кг/шт.)</Label>
                          <Input type="number" defaultValue={product.weight} />
                        </div>
                        <div className="space-y-2">
                          <Label>Цена закупки</Label>
                          <Input type="number" defaultValue={product.price} />
                        </div>
                      </div>
                    </div>
                  ))}

                  <Button variant="outline" className="w-full bg-transparent" onClick={addProduct}>
                    <Plus className="w-4 h-4 mr-2" />
                    Добавить позицию
                  </Button>

                  <div className="flex items-center gap-4 pt-4">
                    <div className="flex-1">
                      <Label htmlFor="margin">Общая маржа (%)</Label>
                      <Input id="margin" type="number" defaultValue="25" className="mt-2" />
                    </div>
                    <div className="flex-1">
                      <Label htmlFor="duty">Пошлина (%)</Label>
                      <Input id="duty" type="number" defaultValue="5" className="mt-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Step 4: Calculation */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Calculator className="w-5 h-5 text-primary" />
                      Итоговый расчёт
                    </CardTitle>
                    <CardDescription>
                      Проверьте расчёт перед генерацией КП
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <div className="flex justify-between py-2 border-b">
                          <span className="text-muted-foreground">Логистика</span>
                          <span className="font-medium">150 000 ₽</span>
                        </div>
                        <div className="flex justify-between py-2 border-b">
                          <span className="text-muted-foreground">НДС (15% от маржи)</span>
                          <span className="font-medium">25 050 ¥</span>
                        </div>
                        <div className="flex justify-between py-2 border-b">
                          <span className="text-muted-foreground">Таможенные платежи</span>
                          <span className="font-medium">1 224 ¥</span>
                        </div>
                        <div className="flex justify-between py-2 border-b">
                          <span className="text-muted-foreground">Себестоимость ед.</span>
                          <span className="font-medium">7 500 ¥</span>
                        </div>
                      </div>
                      <div className="space-y-4">
                        <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                          <p className="text-sm text-muted-foreground">Итоговая цена</p>
                          <p className="text-3xl font-bold text-primary">165 300 ¥</p>
                        </div>
                        <div className="p-4 bg-accent/10 rounded-lg">
                          <p className="text-sm text-muted-foreground">Ожидаемая прибыль</p>
                          <p className="text-2xl font-semibold text-accent">11 339 ¥</p>
                        </div>
                        <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                          <span className="text-muted-foreground">Рентабельность:</span>
                          <Badge className="bg-accent text-accent-foreground">5.54%</Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Курс: 1 ¥ = 14 ₽
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Финансирование</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-4">
                      <Label 
                        className="flex-1 flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer hover:border-primary/50"
                      >
                        <input type="checkbox" className="sr-only" />
                        <div className="w-5 h-5 rounded border-2 border-primary"></div>
                        <span>Кредит</span>
                      </Label>
                      <Label 
                        className="flex-1 flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer hover:border-primary/50"
                      >
                        <input type="checkbox" className="sr-only" />
                        <div className="w-5 h-5 rounded border-2 border-primary"></div>
                        <span>Банковская гарантия</span>
                      </Label>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Navigation */}
            <div className="flex items-center justify-between mt-8">
              <Button 
                variant="outline" 
                onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
                disabled={currentStep === 1}
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Назад
              </Button>

              <div className="flex gap-3">
                <Button variant="outline">Сохранить черновик</Button>
                {currentStep === 4 ? (
                  <Button>
                    Сгенерировать КП
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                ) : (
                  <Button onClick={() => setCurrentStep(Math.min(4, currentStep + 1))}>
                    Далее
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}
